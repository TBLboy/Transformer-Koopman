"""Reproduce the second-order, relative-degree-two example in the proof note.
No user-provided reference input is used. Requires NumPy and SciPy.
"""
import numpy as np
from scipy.linalg import solve_discrete_lyapunov
from scipy.optimize import minimize

A0 = np.array([[0.35, 0.20], [0.0, 0.30]])
B0 = np.array([[0.0], [0.50]])
M0 = np.zeros((5, 5))
M0[:2, :2] = A0
M0[2:4, :2] = np.eye(2)
D0 = np.zeros((5, 1))
D0[:2] = B0
D0[4, 0] = 1.0
C = np.array([[1.0, 0.0, 0.0, 0.0, 0.0]])
Eprev = np.array([[0.0, 0.0, 0.0, 0.0, 1.0]])
Pi = solve_discrete_lyapunov(M0.T, np.eye(5))
Pihalf = np.linalg.cholesky(Pi).T
invPihalf = np.linalg.inv(Pihalf)
lam = np.linalg.norm(Pihalf @ M0 @ invPihalf, 2)
Lu = np.linalg.norm(Pihalf @ D0, 2)
cQ = np.linalg.norm(C @ invPihalf, 2)
hS = np.linalg.norm(Eprev @ invPihalf, 2)
N = 3
omega = 500.0
r = 0.1
G0 = float((C @ np.linalg.solve(np.eye(5)-M0, D0))[0, 0])
u_b = r / G0
q_b = np.linalg.solve(np.eye(5)-M0, D0).reshape(-1) * u_b
A_N = 3*cQ*cQ*sum(lam**(2*i) for i in range(N+1))+hS*hS
omega_min = A_N*Lu*Lu/(1-lam)**2
rho = lam+Lu*np.sqrt(A_N/omega)
assert omega > omega_min and 0 <= rho < 1
assert abs((C @ M0 @ D0)[0,0] - (C @ D0)[0,0]) < 1  # nonessential sanity
assert abs((C @ D0)[0,0]) < 1e-14  # one-step output insensitive to current input
assert abs((C @ M0 @ D0)[0,0] - 0.1) < 1e-14  # two-step sensitivity
assert abs((C @ q_b)[0] - r) < 1e-12

q = np.zeros(5)
warm = np.zeros(N)
E0 = np.linalg.norm(Pihalf @ (q-q_b))
print(f'G0={G0:.8f} u_b={u_b:.6f} lambda={lam:.6f}')
print(f'A_N={A_N:.6f} L_u={Lu:.6f}, omega_min={omega_min:.3f}, omega={omega:.0f}, rho={rho:.6f}')
print(' k      output       |output-r|          E_k        certified E_bound')
for k in range(26):
    E = np.linalg.norm(Pihalf @ (q-q_b))
    y = float((C @ q)[0])
    bound = E0 * rho**k
    if k in (0, 1, 2, 3, 5, 10, 20, 25):
        print(f'{k:2d}   {y: .9f}   {abs(y-r): .9f}    {E: .9f}    {bound: .9f}')
    assert E <= bound + 1e-6, (k, E, bound)
    if k == 25:
        break
    def objective(U):
        p = q.copy()
        value = omega*(U[0]-u_b)**2
        for i in range(N):
            value += (float((C @ p)[0])-r)**2 + (U[i]-float((Eprev @ p)[0]))**2
            p = M0 @ p + D0[:, 0]*U[i]
        return value+(float((C @ p)[0])-r)**2
    res = minimize(objective, warm, method='L-BFGS-B', bounds=[(-2,2)]*N,
                   options={'ftol':1e-13, 'gtol':1e-11, 'maxiter':1000})
    assert res.success or res.fun < 1e-8, res.message
    u = res.x[0]
    q = M0 @ q + D0[:,0]*u
    warm = np.r_[res.x[1:], res.x[-1]]
print('Verified: closed-loop trajectory stays within the claimed exponential envelope (numerical tolerance 1e-6).')
