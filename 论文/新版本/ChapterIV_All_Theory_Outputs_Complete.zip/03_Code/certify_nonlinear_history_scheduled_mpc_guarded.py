"""Fully reproducible analytic certification of a NONZERO history-scheduled Koopman-type model.

This certifies the explicitly defined analytical model, not the user's trained network.
Uses IEEE-style augmented state q=(x1,x2,psi,a1,a2,v), psi=.15*a1.
Only required reference input is scalar output r; anchor u_b=H*r is computed internally.
Outputs JSON and CSV and a PNG plot alongside this script.
"""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
from scipy.linalg import solve_discrete_lyapunov
from scipy.optimize import lsq_linear

HERE=Path(__file__).resolve().parent
np.set_printoptions(precision=9,suppress=True)
N=3; Qw=1.; Sw=1.; M=6.; umax=.6; r=.1; omega=100.; guard_gain=.08
beta=.15; gA=.03; gB=.004; x_star=.1 # fixed model bias, NOT a reference-dependent input
A0=np.array([[.35,.20,0.],[0.,.30,0.],[beta,0.,0.]])
B0=np.array([0.,.5,0.])
M0=np.zeros((6,6));M0[:3,:3]=A0;M0[3,0]=1.;M0[4,1]=1.
D0=np.array([0.,.5,0.,0.,0.,1.])
e1=np.eye(6)[0];e2=np.eye(6)[1]; C=e1.copy();Eprev=np.eye(6)[5]
Pi=solve_discrete_lyapunov(M0.T,np.eye(6)); Ph=np.linalg.cholesky(Pi).T;iPh=np.linalg.inv(Ph)
pnorm=lambda x:float(np.linalg.norm(Ph@x))
lam0=float(np.linalg.norm(Ph@M0@iPh,2))
lu=float(pnorm(D0))
cy=float(np.linalg.norm(C@iPh,2))
a1=float(pnorm(e1));a2=float(pnorm(e2));c1=cy
hs=float(np.linalg.norm(Eprev@iPh,2))
G0=float(C@np.linalg.solve(np.eye(6)-M0,D0)); H=1./G0
cc=np.array([-.15-.03*H,0.,0.,.15,0.,.03])
Lc=float(np.linalg.norm(cc@iPh))
# Explicit global derivative-norm bounds on Pi-ball, uniformly over |u|<=umax
lam=lam0+gA*a1*(c1+c1*M*Lc)+gB*a2*umax*c1
lamfr=lam0+gA*a1*c1
bdrive=umax*(lu+gB*a2)
margin_actual=M-lam*M-bdrive
margin_fr=M-lamfr*M-bdrive
zeta_fr=gA*a1*c1*M+gB*a2*umax
# Along the frozen candidate repeated u_b, compare to nominal skeleton.
d=[0.]
for i in range(N): d.append(lam0*d[-1]+zeta_fr)
AN=3*cy**2*sum(lam0**(2*i) for i in range(N+1))+hs**2
BN=3*cy**2*sum(di**2 for di in d)
# Uniform full-model versus frozen-prediction approximation budget.
eta_uniform=2*zeta_fr
zeta=[0.,0.]
for i in range(2,N+1): zeta.append(lam*zeta[-1]+eta_uniform)
H_Q=cy*M+abs(r)
epsilon_uniform=2*H_Q*cy*sum(zeta[2:])
# Candidate-specific mismatch bound from Lipschitz modulation, no extra complete-model rollout.
K_local=gA*a1*M*cy*Lc+gB*a2*umax*cy
mu_N=4/(N*(N+1))  # S=1
omega_min=AN*lu**2/(1-lam)**2
rho=lam+lu*np.sqrt(AN/omega)
# exact nominal steady selector and actual complete-model equilibrium defect
ub=H*r
qb=np.linalg.solve(np.eye(6)-M0,D0)*ub

def context(q): return float(cc@q)
def A(q):
    mat=A0.copy(); mat[0,0]+=gA*np.tanh(context(q)); return mat
def B(q):
    vec=B0.copy(); vec[1]+=gB*np.tanh(q[0]-x_star); return vec

def full(q,u):
    ans=M0@q+D0*u
    ans[0]+=gA*np.tanh(context(q))*q[0]
    ans[1]+=gB*np.tanh(q[0]-x_star)*u
    return ans

def frozen(q,barq,u):
    ans=M0@q+D0*u
    ans[0]+=gA*np.tanh(context(barq))*q[0]
    ans[1]+=gB*np.tanh(barq[0]-x_star)*u
    return ans

deq=pnorm(full(qb,ub)-qb)
assert deq < 1e-12
rho_guard=lam+lu*guard_gain
assert rho_guard<1
D=deq+lu*np.sqrt(BN/omega) # static reference and exact re-encoding; certified exact QP
radius=cy*D/(1-rho)
cheap=min(cy*M+abs(r),cy*bdrive/(1-lam)+abs(r))
assert gA>0 and gB>0 and lam<1 and lamfr<1
assert margin_actual>0 and margin_fr>0
assert abs(C@qb-r)<1e-12 and abs(Eprev@qb-ub)<1e-12
assert abs(qb[2]-beta*qb[3])<1e-12
assert abs(ub)<=umax and pnorm(qb)<M
assert rho_guard<1 # guard, not large anchor, guarantees stability



# Prediction along nominal sequence is exactly reproduced by the frozen QP at U=nominal.
def freeze_rollout(q,ubar):
    states=[q.copy()]
    for u in ubar: states.append(full(states[-1],float(u)))
    return states

def pred_affine(q,bar):
    # p_i=p0_i + T_i U
    pbase=q.copy(); trans=np.zeros((6,N)); bases=[pbase.copy()];Ts=[trans.copy()]
    for i in range(N):
        Fmat=M0.copy(); Fmat[0,0]+=gA*np.tanh(context(bar[i]))
        Dvec=D0.copy(); Dvec[1]+=gB*np.tanh(bar[i][0]-x_star)
        pbase=Fmat@pbase
        trans=Fmat@trans
        trans[:,i]+=Dvec
        bases.append(pbase.copy()); Ts.append(trans.copy())
    return bases,Ts

def qp_solve(q,ubar):
    bar=freeze_rollout(q,ubar)
    bases,Ts=pred_affine(q,bar)
    # min ||L U - t||^2
    rows=[];targets=[]
    for i in range(N+1):
        rows.append(C@Ts[i]); targets.append(r-float(C@bases[i]))
    for i in range(N):
        row=np.zeros(N); row[i]=1.
        if i: row[i-1]-=1.; target=0.
        else: target=float(Eprev@q)
        rows.append(row);targets.append(target)
    row=np.zeros(N);row[0]=np.sqrt(omega)
    rows.append(row);targets.append(np.sqrt(omega)*ub)
    L=np.vstack(rows); targ=np.asarray(targets)
    candidate=np.linalg.lstsq(L,targ,rcond=None)[0]
    # State-dependent FIRST-INPUT TRUST INTERVAL: always nonempty because it contains ub.
    guard_rad=guard_gain*pnorm(q-qb)
    low=np.array([-umax]*N,dtype=float); high=np.array([umax]*N,dtype=float)
    low[0]=max(-umax,ub-guard_rad); high[0]=min(umax,ub+guard_rad)
    assert low[0]<=ub<=high[0]
    if high[0]-low[0] < 1e-10:
        red=np.linalg.lstsq(L[:,1:],targ-L[:,0]*ub,rcond=None)[0]
        if np.any(np.abs(red)>umax):
            fit=lsq_linear(L[:,1:],targ-L[:,0]*ub,bounds=(-umax,umax),tol=1e-13,max_iter=300)
            assert fit.success,fit.message
            red=fit.x
        U=np.r_[ub,red]
    elif np.all(candidate>=low) and np.all(candidate<=high):
        U=candidate
    else:
        fit=lsq_linear(L,targ,bounds=(low,high),tol=1e-13,max_iter=300)
        assert fit.success, fit.message
        U=fit.x
    # Primal/dual gap certificate for the box-QP, using strong convexity mu_N.
    grad=2*L.T@(L@U-targ)
    yu=np.zeros(N); yl=np.zeros(N)
    for j,v in enumerate(U):
        if j==0 and high[0]-low[0] < 1e-10:
            yu[j]=max(-grad[j],0.);yl[j]=max(grad[j],0.)
        elif v>=high[j]-1e-8:
            assert grad[j]<=1e-7; yu[j]=max(-grad[j],0.)
        elif v<=low[j]+1e-8:
            assert grad[j]>=-1e-7; yl[j]=max(grad[j],0.)
        else: assert abs(grad[j])<1e-7
    station=grad+yu-yl
    delta_certificate=(station@station)/(2*mu_N)+yu@(high-U)+yl@(U-low)
    assert delta_certificate>=-1e-14
    assert abs(U[0]-ub)<=guard_rad+1e-10
    pred=[bases[i]+Ts[i]@U for i in range(N+1)]
    # Check first-step exactness and nominal consistency to full rollout
    assert np.max(np.abs(pred[1]-full(q,U[0])))<1e-10
    bb,tb=pred_affine(q,bar)
    for i,bi in enumerate(bar): assert np.max(np.abs(bb[i]+tb[i]@ubar-bi))<1e-10
    # Candidate-specific discrepancy certificate: |
    # |J_F(U)-J_fr(U)| <= eps_local.
    local_err=[0.]
    for i in range(N):
        delta_pi=pnorm(pred[i]-bar[i])
        local_err.append(lam*local_err[-1]+K_local*delta_pi)
    eps_local=2*H_Q*cy*sum(local_err[2:])
    def objective_frozen(Uvals):
        qps=[bases[j]+Ts[j]@Uvals for j in range(N+1)]
        total=omega*(Uvals[0]-ub)**2
        for j in range(N):
            prev=(q[5] if j==0 else Uvals[j-1])
            total+=(float(C@qps[j])-r)**2 + (Uvals[j]-prev)**2
        return total+(float(C@qps[N])-r)**2
    def objective_full(Uvals):
        qf=q.copy()
        total=omega*(Uvals[0]-ub)**2
        for j in range(N):
            prev=(q[5] if j==0 else Uvals[j-1])
            total+=(float(C@qf)-r)**2+(Uvals[j]-prev)**2
            qf=full(qf,Uvals[j])
        return total+(float(C@qf)-r)**2
    mismatch=abs(objective_full(U)-objective_frozen(U))
    assert mismatch<=eps_local+1e-11
    improve_nominal=objective_frozen(ubar)-objective_frozen(U)
    return U,pred,bar,dict(delta_certificate=float(delta_certificate),eps_local=float(eps_local),
                             measured_full_frozen_objective_gap=float(mismatch),
                             frozen_cost_improvement_over_nominal=float(improve_nominal),
                             certified_full_cost_improvement=float(improve_nominal-eps_local))

# Simulated physical dynamics: x^+=(A0[:2,:2] x + [gA tanh(c) x1, gB tanh(x1) u] + [0, .5 u]);
# psi^+=beta*x1, a^+=x, v^+=u. Therefore exactly q^+=F(q,u), w=0.
q=np.array([-0.5,0.0,beta*0.5,0.5,0.0,-0.1]);barU=np.zeros(N)
E0=pnorm(q-qb)
records=[]; d_gains=[]; scheduledA=[]; scheduledB=[]; diagnostics=[]
for k in range(61):
    E=pnorm(q-qb); y=float(C@q); err=abs(y-r)
    bound=cy*rho_guard**k*E0
    assert err<=bound+1e-9,(k,err,bound)
    assert E<M+1e-9
    records.append(dict(k=k,y=y,abs_output_error=err,output_error_bound=bound,augmented_error=E))
    if k==60: break
    U,pred,bar,diag=qp_solve(q,barU)
    diagnostics.append(diag)
    scheduledA.append(gA*np.tanh(context(q)))
    scheduledB.append(gB*np.tanh(q[0]-x_star))
    qnext=full(q,U[0]);assert np.max(np.abs(qnext[2]-beta*q[0]))<1e-12
    assert np.max(np.abs(qnext[3:5]-q[:2]))<1e-12
    assert abs(qnext[5]-U[0])<1e-12
    q=qnext
    barU=np.r_[U[1:],U[-1]]

assert max(abs(v) for v in scheduledA)>1e-6,'A schedule must be active (nonzero)'
assert max(abs(v) for v in scheduledB)>1e-6,'B schedule must be active (nonzero)'
const={
    'gA':gA,'gB':gB,'fixed_B_bias_x_star':x_star,'M':M,'U_max':umax,'reference_r':r,'N':N,'omega':omega,
    'lambda0':lam0,'lambda_full_upper':lam,'lambda_frozen_upper':lamfr,
    'invariance_margin_actual':margin_actual,'invariance_margin_frozen':margin_fr,
    'G0':G0,'H':H,'u_b':ub,'q_b_norm_Pi':pnorm(qb),'q_b':qb.tolist(),
    'L_u':lu,'a1':a1,'a2':a2,'c_y':cy,'L_c_Pi':Lc,
    'zeta_fr_upper':zeta_fr,'d_i':d,
    'A_N':AN,'B_N':BN,'omega_min':omega_min,'rho':rho,
    'equilibrium_defect_exact':deq,'D':D,
    'certified_output_final_radius':0.,'cheap_original_output_radius':cheap,
    'bound_ratio_new_over_old':0.,
    'max_nonzero_A_schedule_abs':max(abs(v) for v in scheduledA),
    'max_nonzero_B_schedule_abs':max(abs(v) for v in scheduledB),
    'sim_k10_output':records[10]['y'],'sim_k20_output':records[20]['y'],
    'sim_k40_output':records[40]['y'],'sim_k60_output':records[60]['y'],
    'simulation_max_actual_error_after_k20':max(x['abs_output_error'] for x in records if x['k']>=20),
    'guard_gain':guard_gain,'guard_rho':rho_guard,
    'guard_theorem_final_radius':0.,
    'guard_weight_requirement':'none; guard provides contraction, anchor omega=100 is optional',
    'anchor_only_rho_at_this_weight':rho,
    'anchor_only_bound_inapplicable':True,
    'model_reencoding_residual':0.0,
    'eta_uniform':eta_uniform,'freeze_cost_gap_uniform':epsilon_uniform,'K_local':K_local,
    'max_delta_certificate':max(a['delta_certificate'] for a in diagnostics),
    'sample0_local_full_frozen_cost_gap_bound':diagnostics[0]['eps_local'],
    'sample0_actual_full_frozen_cost_gap':diagnostics[0]['measured_full_frozen_objective_gap'],
    'sample0_nominal_full_model_improvement_certificate':diagnostics[0]['certified_full_cost_improvement'],
    'certification_note':'This certifies this explicitly specified analytic nonzero-history-scheduled model, NOT any trained Transformer network.'
}
with (HERE/'nonzero_schedule_guarded_certificate.json').open('w') as f:json.dump(const,f,indent=2,ensure_ascii=False)
with (HERE/'nonzero_schedule_guarded_closed_loop.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(records[0].keys()));w.writeheader();w.writerows(records)
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,4.6))
    ax.semilogy([x['k'] for x in records],[max(x['abs_output_error'],1e-14) for x in records],label='Actual output error')
    ax.semilogy([x['k'] for x in records],[x['output_error_bound'] for x in records],label='Certified time-varying bound')
    # The guard certifies convergence to zero; no log-plot horizontal line at zero.
    ax.axhline(cheap,linestyle=':',label='Old cheap ultimate bound')
    ax.set(xlabel='Discrete time k',ylabel='Absolute output error / upper bound (log scale)',title='Guarded QP: nonzero A/B scheduling, exact nonlinear equilibrium')
    ax.legend(fontsize=8);ax.grid(alpha=.3,which='both');fig.tight_layout()
    fig.savefig(HERE/'nonzero_schedule_guarded_tracking.png',dpi=180)
    plt.close(fig)
except ImportError:pass
for k in ('guard_gain','guard_rho','lambda0','lambda_full_upper','lambda_frozen_upper','invariance_margin_actual','invariance_margin_frozen','G0','u_b','A_N','B_N','omega_min','equilibrium_defect_exact','certified_output_final_radius','cheap_original_output_radius','bound_ratio_new_over_old','max_nonzero_A_schedule_abs','max_nonzero_B_schedule_abs','sim_k10_output','sim_k20_output','sim_k60_output','max_delta_certificate','freeze_cost_gap_uniform','sample0_local_full_frozen_cost_gap_bound','sample0_actual_full_frozen_cost_gap','sample0_nominal_full_model_improvement_certificate'):
    print(f'{k:40s}: {const[k]:.10f}')
print('All analytical inequality tests, KKT residual checks, exact re-encoding consistency, model-structure checks, and closed-loop envelope tests passed.')
