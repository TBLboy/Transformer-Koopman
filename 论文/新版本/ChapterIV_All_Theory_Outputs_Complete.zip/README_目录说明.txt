第四章理论阶段——完整产出材料归档

01_Proofs：英文定理证明 PDF 与 LaTeX 源文件（初始锚定方案及非零调度补充证明）。
02_Chinese_Reports：中文证明说明、非零调度认证报告及前期理论路线审查。
03_Code：数值检验与认证 Python 程序。
04_Certification_Data：认证常数 JSON 和闭环轨迹 CSV。
05_Plots：数值检验图。

注意：本包是理论研究与验证材料，不代表已经针对实际训练 Transformer 网络完成认证，也不是已经重写的第四章。
